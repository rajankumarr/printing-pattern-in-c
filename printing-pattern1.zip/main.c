

#include <stdio.h>

int main()
{
    int i,j,s,n;
    printf("Enter the value of S\n");
    scanf("%d",&s);
    printf("Enter the value of N\n");
    scanf("%d",&n);
    
    
   for(i=s;i<=s+3;i++)
   {
       for(j=s;j<=i;j++)
       {
       printf("%d",i);
       }
        printf("\n");
   }
   
    for(i=s+3-1;i>=s;i--)
   {
       for(j=s;j<=i;j++)
       {
       printf("%d",i);
       }
        printf("\n");
   }
  

    return 0;
}
