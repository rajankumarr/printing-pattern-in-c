

#include <stdio.h>

int main()
{
    int i,j,s,n;
    //printf("Enter the value of S\n");
    //scanf("%d",&s);
    printf("Enter the value of N\n");
    scanf("%d",&n);
    
    
   for(i=1;i<=n;i++)
   {
        int k=1;
       for(j=1;j<=i;j++)
       
       {
       printf("%d",i);
       if(k<i)
        {
        printf("*");
            k=k+1;
        }
       }
        printf("\n");
   }
   
    for(i=n;i>=1;i--)
   {
       int k=1;
       for(j=1;j<=i;j++)
       {
       printf("%d",i);
       if(k<i)
        {
        printf("*");
            k=k+1;
        }
       }
        printf("\n");
   }
  

    return 0;
}
