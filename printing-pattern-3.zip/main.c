

#include <stdio.h>

int main()
{
    int i,j,s,n;
    printf("Enter the value of N\n");
    scanf("%d",&n);
    int num=0;
    
   for(i=1;i<=n;i++)
   {
        int k=1;
       for(j=1;j<=i;j++)
       
       {
       printf("%d", num+1);
        num++;
       if(k<i)
        {
        printf("*");
            k=k+1;
        }
       }
        printf("\n");
   }
}
